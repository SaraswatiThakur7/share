import { LightningElement, track } from 'lwc';
import {wire} from 'lwc';
import getAccounts from '@salesforce/apex/Assignment1Class.getAccounts';
export default class Aasignment01 extends LightningElement {
    
@track myaccountdetails;//Account data fetched from imperative call
@track searchTerm; //Data stored captured under Name input tag
@track nos;//Data stored captured under Record tag
@track searchfilterData; //Data stored taged under Filter tag
@track copy; //Account copy Data

//@track filterTerm;
    constructor(){
        super();
        console.log('In the constructor');
    }
    //User input name/Records block
    handleInput(event){
        if(event.target.name=='Name'){
            console.log( event.target.value);
            this.searchTerm=event.target.value;
        }else if(event.target.name=='Record'){
            this.nos=event.target.value;
            console.log( event.target.value);
        }else if(event.target.name=='filter'){ 
            this.searchfilterData=event.target.value;
        }
    }
    //search button functionality- Imperative call
    async handleSearchTermDetails(){
        console.log('inside handleSearchTermDetails');
        
        console.log(this.searchTerm+' value '+ this.nos);
        //query from method : Assignment1Class.getAccounts arguments : Name, record nos
        let result=await getAccounts({Name:this.searchTerm,Nos:this.nos});
        console.log(result);
        this.myaccountdetails=result;
        this.copy=result;
        
    }    

    
  //processing of Searchfiltered Data
  handleFilteredTermDetails(){
       console.log(this.copy);
        
        this.copy=this.copy.filter(item=>{
          return  item.Name.includes(this.searchfilterData);
        });
        


   }
  
 }