import { LightningElement, api } from 'lwc';

export default class AasignmantChild01 extends LightningElement {
    @api account;
}